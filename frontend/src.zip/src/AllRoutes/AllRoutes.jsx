import React from 'react'

const AllRoutes = () => {
  return (
    <div>
      
    </div>
  )
}

export default AllRoutes
